import {
  HttpClientTestingModule,
  HttpTestingController,
} from "@angular/common/http/testing";
import { DebugElement } from "@angular/core";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule } from "@angular/forms";
import { By } from "@angular/platform-browser";
import { NgMultiSelectDropDownModule } from "ng-multiselect-dropdown";
import { of } from "rxjs";
import { DialogComponent } from "src/app/shared/components/dialog/dialog.component";
import { HeaderComponent } from "src/app/shared/components/header/header.component";
import { StatsFilterComponent } from "src/app/shared/components/stats-filter/stats-filter.component";
import { FilterPokemonPipe } from "src/app/shared/pipes/filter-pokemon.pipe";
import { PokemonService } from "src/app/shared/services/pokemon.service";
import { PokemonDetailsComponent } from "../pokemon-details/pokemon-details.component";
import { PokemonItemComponent } from "../pokemon-item/pokemon-item.component";
import { PokemonListComponent } from "./pokemon-list.component";

describe("PokemonListComponent", () => {
  let component: PokemonListComponent;
  let httpMock: HttpTestingController;
  let fixture: ComponentFixture<PokemonListComponent>;
  let pokemonService: PokemonService;
  let el: DebugElement;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        NgMultiSelectDropDownModule,
        FormsModule,
      ],
      providers: [PokemonService],
      declarations: [
        PokemonListComponent,
        HeaderComponent,
        PokemonDetailsComponent,
        PokemonItemComponent,
        FilterPokemonPipe,
        DialogComponent,
        StatsFilterComponent,
      ],
    }).compileComponents();
    httpMock = TestBed.inject(HttpTestingController);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PokemonListComponent);
    component = fixture.componentInstance;
    pokemonService = TestBed.inject(PokemonService);
    fixture.detectChanges();
    el = fixture.debugElement;
  });

  it("should create pokemon-empty-state", () => {
    const cards = el.queryAll(By.css(".pokemon-empty-state"));
    expect(cards).toBeTruthy();
  });
  it("should fetch data if not all data has been fetched", () => {
    component.pokemonList = [{ name: "pokemon1" }];
    component.pokemonCount = 2;
    spyOn(pokemonService, "getPokemonData").and.returnValue(
      of({ count: 2, results: [{ name: "pokemon2" }] }),
    );
    component.getPokemonList();
    expect(pokemonService.getPokemonData).toHaveBeenCalled();
  });
});
